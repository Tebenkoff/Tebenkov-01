﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PraktFomin1
{
    public partial class FormOsn : Form
    {
        int old_x, old_y; // old mouse coordinates
        List<Figure> lst = new List<Figure>(); // array of figure

        // the function of creating a new figure
        Figure createFigure(string fig_type)
        {
            switch(fig_type)
            {
                case "circle": return new Circle();
                case "square": return new Square();
                case "triangle": return new Triangle();
            }
            return null;
        }

        public FormOsn()
        {
            InitializeComponent();
        }

        private void pictureBoxDraw_Paint(object sender, PaintEventArgs e)
        {
            // paints the entire drawing area white
            e.Graphics.FillRectangle(Brushes.White, 0, 0, pictureBoxDraw.Width, pictureBoxDraw.Height);

            // cycle(loop) for an array
            // draws figures
            foreach (Figure fig in lst)
                fig.draw(e.Graphics);
        }

        private void pictureBoxDraw_MouseDown(object sender, MouseEventArgs e)
        {
            // shift + left-click - selecting multiple figure
            if (Control.ModifierKeys == Keys.Shift && e.Button == MouseButtons.Left)
            {
                for (int i = 0; i < lst.Count; i++)
                {
                    Figure fig = lst[i];
                    fig.selected |= fig.test(e.X, e.Y);
                    if (fig.selected == true)
                        listBoxFigure.SelectedItem = fig.name;
                }
                pictureBoxDraw.Invalidate();
            }

            // left-click
            else if (e.Button == MouseButtons.Left)
            {
                // zeroing the selection
                foreach (Figure fig in lst)
                    fig.selected = false;
                listBoxFigure.SelectedItem = null;

                for (int i = 0; i < lst.Count; i++)
                {
                    Figure fig = lst[i];
                    fig.selected |= fig.test(e.X, e.Y);
                    if (fig.selected == true)
                    {
                        listBoxFigure.SelectedItem = fig.name;
                        break;
                    }
                }
                pictureBoxDraw.Invalidate();
            }

            // right-click
            else if (e.Button == MouseButtons.Right)
            {
                List <string> listName= new List<string> (); // array of names

                // zeroing the selection
                foreach (Figure fig in lst)
                {
                    fig.selected = false;
                    listName.Add(fig.name);
                }
                listBoxFigure.SelectedItem = null;

                string new_name;
                for (int i = 0; i < lst.Count; i++)
                {
                    Figure fig = lst[i];
                    fig.selected |= fig.test(e.X, e.Y);
                    if (fig.selected == true)
                    {
                        listBoxFigure.SelectedItem = fig.name;
                        new_name = Interaction.InputBox("Имя фигуры: " + fig.name + "\nВведите новое имя", "Переименование");

                        // Name verification (must not match existing names and cannot be empty)
                        // If the user selects Cancel, a zero-length string is returned ("").
                        if (listName.Contains(new_name) == false && new_name != "")
                        {
                            listBoxFigure.Items.Remove(fig.name);
                            fig.name = new_name;
                            listBoxFigure.Items.Add(fig.name);
                        }
                        else if (listName.Contains(new_name) == true && new_name != "")
                            MessageBox.Show("Имя занято", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);                        
                        break;
                    }
                }
                pictureBoxDraw.Invalidate();
            }
        }

        private void pictureBoxDraw_MouseMove(object sender, MouseEventArgs e)
        {
            // moving a figure
            if (e.Button == MouseButtons.Left)
            {
                int dx = e.X - old_x;
                int dy = e.Y - old_y;
                foreach (Figure fig in lst)
                {
                    if (fig.selected == false) continue;
                    fig.pos_x += dx;
                    fig.pos_y += dy;
                }
                pictureBoxDraw.Invalidate();
            }
            old_x = e.X;
            old_y = e.Y;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Figure fig = createFigure(comboBoxFigure.Text);
            if (fig == null) return;
            fig.pos_x = pictureBoxDraw.Width / 2.0f; // center of the pictureBox
            fig.pos_y = pictureBoxDraw.Height / 2.0f;
            lst.Add(fig);
            
            listBoxFigure.Items.Add(fig.nameFigure()); // add a name to the list

            pictureBoxDraw.Invalidate();
        }

        private void buttonDel_Click(object sender, EventArgs e)
        {
            // confirmation of deletion if more than one figure is selected
            if (listBoxFigure.SelectedItems.Count > 1)
            {
                DialogResult result;
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;

                result = MessageBox.Show("Вы точно хотите удалить?", "Предупреждение", buttons, MessageBoxIcon.Warning);
                if (result == DialogResult.No) return;
            }

            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i].selected == true)
                {
                    listBoxFigure.Items.Remove(lst[i].name); // remove a name from the list
                    lst.RemoveAt(i);  // delete the selected figure
                    i--; // due to the offset of the list items
                }
            }

            pictureBoxDraw.Invalidate();
        }

        // selecting a figure from the list
        private void listBoxFigure_SelectedIndexChanged(object sender, EventArgs e)
        {           
            for (int i = 0; i < lst.Count; i++)
            {
                Figure fig = lst[i];
                for (int j = 0; j < listBoxFigure.SelectedItems.Count; j++)
                {
                    if (Convert.ToString(listBoxFigure.SelectedItems[j]) == fig.name)
                    {
                        fig.selected = true;
                        break;
                    }
                    fig.selected = false;
                }
                if (listBoxFigure.SelectedItems.Count == 0) fig.selected = false;
            }
            pictureBoxDraw.Invalidate();
        }
    }
}
