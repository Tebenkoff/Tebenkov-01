﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PraktFomin1
{
    class Figure
    {
        public float pos_x, pos_y; // coordinates of the center of the figure
        public bool selected;
        public string name;
        
        // checking if a point gets inside the figure
        virtual public bool test(float x, float y)
        {
            return false;
        }

        // drawing a figure on the screen
        virtual public void draw(Graphics g)
        {

        }

        // name + number
        virtual public string nameFigure()
        {
            return name;
        }
    }
}
