﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraktFomin1
{
    class Circle : Figure
    {
        public float radius, radius_squared, diameter;
        static int n = 1; // counter

        public Circle()
        {
            radius = 50.0f;
            radius_squared = radius * radius;
            diameter = radius * 2.0f;
        }

        // setting the radius
        public void setRadius(float new_radius)
        {
            if (new_radius < 0) return;
            radius = new_radius;
            radius_squared = radius * radius;
            diameter = radius * 2.0f;
        }        

        // checking if a point gets inside the circle
        // (x - x0)^2 + (y - y0)^2 <= radius^2
        // x0 and y0 - coordinates of the center of the circle
        public override bool test(float x, float y)
        {
            //float radius_squared = radius * radius;

            float dx = x - pos_x; // (x - x0)
            float dy = y - pos_y; // (y - y0)
            if (dx * dx + dy * dy <= radius_squared) return true;
            else return false;
        }
        // drawing a circle on the screen
        public override void draw(Graphics g)
        {
            //float diameter = radius * 2.0f;

            // x0 and y0 - the upper left corner of the square in which the circle is inscribed
            float x0 = pos_x - radius;
            float y0 = pos_y - radius;
            Pen pen = Pens.Black;
            if (selected == true) pen = Pens.Red; // if the circle is selected
            g.DrawEllipse(pen, x0, y0, diameter, diameter);
        }

        // name + number
        public override string nameFigure()
        {
            name = "circle" + Convert.ToString(n);
            n++;
            return name;
        }
    }
}
