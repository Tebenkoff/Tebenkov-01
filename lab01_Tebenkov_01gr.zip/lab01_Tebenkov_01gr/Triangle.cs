﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PraktFomin1
{
    class Triangle : Figure
    {
        public float side, angle, R;
        public Point[] p = new Point[3]; // coordinates of the vertices    
        public float a, b, c;
        static int n = 1; // counter

        // R = a / sqrt(3)   --- the radius of the circumscribed circle
        public Triangle()
        {
            side = 100;
            R = side / (float) Math.Sqrt(3);
        }

        // setting the side
        public void setSideTr(float new_side)
        {
            if (new_side < 0) return;
            side = new_side;
            R = side / (float)Math.Sqrt(3);

        }
        // x0, y0; x1, y1; x2, y2 - coordinates of the vertices  
        // x, y - coordinates of the point (mouse)
        //a = (x0 - x) * (y1 - y0) - (x1 - x0) * (y0 - y)
        //b = (x1 - x) * (y2 - y1) - (x2 - x1) * (y1 - y)
        //c = (x2 - x) * (y0 - y2) - (x0 - x2) * (y2 - y)
        // If they are of the same sign, then the point is inside the triangle,
        // if any of this is zero, then the point lies on the side,
        // otherwise the point is outside the triangle
        public override bool test(float x, float y)
        {
            a = (p[0].X - x) * (p[1].Y - p[0].Y) - (p[1].X - p[0].X) * (p[0].Y - y);
            b = (p[1].X - x) * (p[2].Y - p[1].Y) - (p[2].X - p[1].X) * (p[1].Y - y);
            c = (p[2].X - x) * (p[0].Y - p[2].Y) - (p[0].X - p[2].X) * (p[2].Y - y);

            if ((a >= 0 && b >= 0 && c >= 0) || (a <= 0 && b <= 0 && c <= 0)) return true;
            return false;
        }

        // drawing a triangle on the screen
        public override void draw(Graphics g)
        {
            angle = 2 * (float) Math.PI / 3.0f; // the angle between the vertices

            for (int i = 0; i < 3; i++)
            {
                p[i].X = (int)(pos_x + R * Math.Cos(angle * i));
                p[i].Y = (int)(pos_y - R * Math.Sin(angle * i));
            }

            Pen pen = Pens.Black;
            if (selected == true) pen = Pens.Red;
            g.DrawPolygon(pen, p);
        }

        // name + number
        public override string nameFigure()
        {
            name = "triangle" + Convert.ToString(n);
            n++;
            return name;
        }
    }
}
