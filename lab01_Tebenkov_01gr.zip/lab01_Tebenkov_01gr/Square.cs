﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraktFomin1
{
    class Square : Figure
    {
        public float side, half_side;
        static int n = 1; // counter

        public Square()
        {
            side = 100;
            half_side = side * 0.5f;
        }

        // setting the side
        public void setSide(float new_side)
        {
            if (new_side < 0) return;
            side = new_side;
            half_side = side * 0.5f;
        }

        public override bool test(float x, float y)
        {
            //float half_side = side * 0.5f;

            // the borders of the square
            float xmin = pos_x - half_side;
            float ymin = pos_y - half_side;
            float xmax = pos_x + half_side;
            float ymax = pos_y + half_side;
            if (x < xmin || x > xmax || y < ymin || y > ymax) return false;
            else return true;
        }
        // drawing a square on the screen
        public override void draw(Graphics g)
        {
            //float half_side = side * 0.5f;

            // x0 and y0 - the upper left corner of the square
            float x0 = pos_x - half_side;
            float y0 = pos_y - half_side;
            Pen pen = Pens.Black;
            if (selected == true) pen = Pens.Red;
            g.DrawRectangle(pen, x0, y0, side, side);
        }

        // name + number
        public override string nameFigure()
        {
            name = "square" + Convert.ToString(n);
            n++;
            return name;
        }
    }
}
